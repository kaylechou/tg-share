#!/usr/bin/env python3
"""合成两个戏剧性音效：车祸、打雷下雨。48kHz 立体声 WAV。"""
import numpy as np
from scipy import signal
import wave, os

SR = 48000
OUT = "/home/hatch/workspace/imagine_media"

def write_wav(path, stereo):
    x = np.clip(stereo, -1.0, 1.0)
    pcm = (np.asarray(x) * 32767).astype(np.int16)
    with wave.open(path, "wb") as w:
        w.setnchannels(2)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(pcm.T.tobytes())
    print("wrote", path, "shape", pcm.shape)

def bp(x, low, high, order=4):
    b, a = signal.butter(order, [low / (SR / 2), high / (SR / 2)], btype="band")
    return signal.lfilter(b, a, x)

def lp(x, cut, order=4):
    b, a = signal.butter(order, cut / (SR / 2), btype="low")
    return signal.lfilter(b, a, x)

def hp(x, cut, order=4):
    b, a = signal.butter(order, cut / (SR / 2), btype="high")
    return signal.lfilter(b, a, x)

def exp_env(n, tau, sr=SR):
    return np.exp(-np.arange(n) / sr / tau)

def stereo_noise(n, rng):
    return np.vstack([rng.standard_normal(n), rng.standard_normal(n)])

def add_at(mix, layer, start_s):
    """把 layer（2,N 或 1D）加进 mix 的 start_s 位置。"""
    s = int(round(start_s * SR))
    if layer.ndim == 1:
        layer = np.vstack([layer, layer])
    n = layer.shape[1]
    e = min(n, mix.shape[1] - s)
    if e <= 0:
        return mix
    mix[:, s:s + e] += layer[:, :e]
    return mix

def norm(mix, peak=0.95):
    m = np.max(np.abs(mix))
    if m > 0:
        mix = mix / m * peak
    return mix

# ================= 车祸 9 秒 =================
def car_crash(rng):
    dur = 9.0
    n = int(dur * SR)
    mix = np.zeros((2, n))
    t = np.arange(n) / SR

    # 0-0.5s 轮胎急刹尖啸：频率上扬的啸叫 + 高频噪声，音量递增
    ns = int(0.5 * SR)
    tt = np.arange(ns) / SR
    ramp = np.linspace(0.15, 1.0, ns) ** 1.5
    chirp = signal.chirp(tt, f0=900, f1=2400, t1=0.5, method="linear")
    tone = chirp * ramp * 0.28
    nz = bp(rng.standard_normal(ns), 1500, 3800) * ramp * 0.35
    mix = add_at(mix, tone + nz, 0.0)

    # 0.5s 巨大撞击：低频重击 65Hz+45Hz
    ni = int(1.2 * SR)
    ti = np.arange(ni) / SR
    thump = (np.sin(2 * np.pi * 65 * ti) * 0.9 + np.sin(2 * np.pi * 45 * ti) * 0.6) * exp_env(ni, 0.16)
    thump *= np.minimum(1.0, ti / 0.004)  # 4ms 快速起音
    mix = add_at(mix, thump, 0.5)

    # 金属挤压碎裂：300-2000Hz 带通噪声，衰减
    crunch = bp(rng.standard_normal(ni), 300, 2000) * exp_env(ni, 0.45) * 0.95
    crunch2 = bp(rng.standard_normal(ni), 800, 3500) * exp_env(ni, 0.25) * 0.5
    mix = add_at(mix, crunch, 0.5)
    mix = add_at(mix, crunch2, 0.5)

    # 玻璃碎裂：高频噪声短爆
    gb = int(0.12 * SR)
    glass = hp(rng.standard_normal(gb), 6000) * exp_env(gb, 0.03) * 0.7
    mix = add_at(mix, glass, 0.5)
    for gs in [0.62, 0.78, 0.95, 1.15]:
        g2 = int(0.04 * SR)
        g = hp(rng.standard_normal(g2), 5000) * exp_env(g2, 0.012) * rng.uniform(0.25, 0.5)
        mix = add_at(mix, g, gs)

    # 0.5-2s 金属持续扭曲：多段噪声爆点依次衰减
    for ts, amp, lo, hi, tau in [(0.7, 0.55, 400, 1200, 0.22),
                                 (1.0, 0.45, 300, 1000, 0.25),
                                 (1.35, 0.32, 500, 1500, 0.2),
                                 (1.7, 0.22, 350, 900, 0.25)]:
        nb = int(0.5 * SR)
        b = bp(rng.standard_normal(nb), lo, hi) * exp_env(nb, tau) * amp
        mix = add_at(mix, b, ts)

    # 二次撞击（1.2s）：较小的低频重击
    n2 = int(0.5 * SR)
    t2 = np.arange(n2) / SR
    th2 = np.sin(2 * np.pi * 55 * t2) * exp_env(n2, 0.12) * 0.45
    mix = add_at(mix, th2, 1.2)

    # 2-4s 碎片散落：小噪声爆点 + 玻璃叮当
    for _ in range(18):
        ds = rng.uniform(2.0, 4.0)
        dl = int(rng.uniform(0.005, 0.03) * SR)
        d = hp(rng.standard_normal(dl), 4500) * exp_env(dl, 0.008) * rng.uniform(0.05, 0.22)
        mix = add_at(mix, d, ds)
    for fs, fq in [(2.3, 3200), (2.9, 4100), (3.4, 2800), (3.8, 3600)]:
        fl = int(0.25 * SR)
        ft = np.arange(fl) / SR
        tink = np.sin(2 * np.pi * fq * ft) * exp_env(fl, 0.06) * 0.10
        mix = add_at(mix, tink, fs)

    # 4-8s 低频轰鸣余响渐弱（延长到 6.5s，接上金属呻吟，不留 2 秒死寂）
    nr = int(6.0 * SR)
    rumble = lp(rng.standard_normal(nr), 130) * exp_env(nr, 1.8) * 0.5
    mix = add_at(mix, rumble, 0.5)
    # 低频正弦余响
    rt = np.arange(nr) / SR
    rumble2 = np.sin(2 * np.pi * 38 * rt) * exp_env(nr, 2.2) * 0.35
    mix = add_at(mix, rumble2, 0.5)

    # 6.5-8.5s 金属呻吟收尾：频率微颤的低音
    gl = int(2.0 * SR)
    gt = np.arange(gl) / SR
    wob = 110 + 18 * np.sin(2 * np.pi * 2.2 * gt)
    ph = 2 * np.pi * np.cumsum(wob) / SR
    groan = np.sin(ph) * 0.22
    fade = np.minimum(1.0, gt / 0.4) * np.minimum(1.0, (2.0 - gt) / 0.6)
    mix = add_at(mix, groan * fade, 6.5)

    return norm(mix)

# ================= 打雷下雨 12 秒 =================
def thunder_rain(rng):
    dur = 12.0
    n = int(dur * SR)
    mix = np.zeros((2, n))
    t = np.arange(n) / SR

    # 雨声基底 0-12s：低通噪声 + 中频雨点声，缓慢幅度起伏
    rain_lp = lp(stereo_noise(n, rng), 2600) * 0.42
    rain_bp = bp(stereo_noise(n, rng), 800, 2600) * 0.30
    # 缓慢随机幅度调制（雨势起伏）
    mod_t = np.arange(n) / SR
    slow = 0.75 + 0.25 * np.sin(2 * np.pi * 0.13 * mod_t + 0.7) * np.sin(2 * np.pi * 0.07 * mod_t)
    mix += rain_lp * slow
    mix += rain_bp * slow
    # 雨滴点缀：随机小爆点
    for _ in range(60):
        ds = rng.uniform(0.2, 11.5)
        dl = int(rng.uniform(0.004, 0.015) * SR)
        d = hp(rng.standard_normal(dl), 3500) * exp_env(dl, 0.004) * rng.uniform(0.03, 0.10)
        mix = add_at(mix, d, ds)

    # 0-3s 远处闷雷低鸣
    nr0 = int(3.0 * SR)
    far = lp(stereo_noise(nr0, rng), 90) * np.linspace(0.05, 0.22, nr0)
    mix = add_at(mix, far, 0.0)

    # 3.0s 闪电劈裂：尖锐噪声爆点
    ck = int(0.07 * SR)
    crack = hp(rng.standard_normal(ck), 1200) * exp_env(ck, 0.015) * 1.0
    crack *= np.minimum(1.0, np.arange(ck) / (0.002 * SR))
    mix = add_at(mix, crack, 3.0)

    # 3.0s 巨大雷声：低频轰鸣 + 45Hz 正弦，长衰减
    nt = int(5.5 * SR)
    tt = np.arange(nt) / SR
    th = lp(stereo_noise(nt, rng), 120) * exp_env(nt, 2.2) * 1.0
    th += lp(stereo_noise(nt, rng), 60) * exp_env(nt, 2.8) * 0.5
    th_sine = np.sin(2 * np.pi * 45 * tt) * exp_env(nt, 1.8) * 0.55
    # 滚动感：慢速幅度调制
    roll = 0.7 + 0.3 * np.sin(2 * np.pi * 0.9 * tt) * np.sin(2 * np.pi * 0.37 * tt + 1.0)
    mix = add_at(mix, th * roll, 3.0)
    mix = add_at(mix, th_sine * roll, 3.0)

    # 二次雷峰 4.6s、6.2s：滚动中的加强
    for ts, amp in [(4.6, 0.45), (6.2, 0.28)]:
        nb = int(2.0 * SR)
        b = lp(stereo_noise(nb, rng), 100) * exp_env(nb, 0.9) * amp
        mix = add_at(mix, b, ts)

    # 9.5s 较小的闷雷（低通会削弱噪声能量，幅度给足才能在雨声上听见）
    n9 = int(2.0 * SR)
    t9 = np.arange(n9) / SR
    small = lp(stereo_noise(n9, rng), 110) * exp_env(n9, 1.2) * 0.65
    small += np.sin(2 * np.pi * 50 * t9) * exp_env(n9, 1.0) * 0.30
    mix = add_at(mix, small, 9.5)

    # 整体淡出最后 0.5s
    fade = np.ones(n)
    fade[-int(0.5 * SR):] = np.linspace(1.0, 0.0, int(0.5 * SR))
    mix = mix * fade
    return norm(mix)

def check(name, mix, marks):
    peak = np.max(np.abs(mix))
    print(f"[{name}] peak={peak:.3f} dur={mix.shape[1]/SR:.2f}s")
    # 每 0.5s 的 RMS
    win = int(0.5 * SR)
    rms = []
    for i in range(0, mix.shape[1], win):
        seg = mix[:, i:i + win]
        rms.append(float(np.sqrt(np.mean(seg ** 2))))
    print("  0.5s RMS:", " ".join(f"{v:.2f}" for v in rms))
    for m in marks:
        s = int(m * SR)
        seg = mix[:, max(0, s - win // 2):s + win // 2]
        print(f"  mark {m}s RMS={float(np.sqrt(np.mean(seg**2))):.2f} peak={float(np.max(np.abs(seg))):.2f}")
    if peak > 0.99:
        print("  WARNING: 接近削波！")

if __name__ == "__main__":
    os.makedirs(OUT, exist_ok=True)
    rng = np.random.default_rng(20261109)
    car = car_crash(rng)
    check("car-crash", car, [0.25, 0.5, 1.0, 3.0, 7.5])
    write_wav(os.path.join(OUT, "car-crash-dramatic.wav"), car)
    tr = thunder_rain(rng)
    check("thunder-rain", tr, [1.0, 3.0, 5.0, 9.5])
    write_wav(os.path.join(OUT, "thunder-rain-dramatic.wav"), tr)
    print("done")
