# -*- coding: utf-8 -*-
"""《赐平安的神，成全你》PPT（规则1：全部加粗、雅黑经文、黑体红色引用、2张淡色背景图）"""
import os
from PIL import Image
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.shapes import MSO_SHAPE

OUT_DIR = os.path.expanduser('~/workspace/your_files/ci-ping-an-de-shen')
BG_DIR = '/tmp/ppt_bg6'
os.makedirs(OUT_DIR, exist_ok=True)
os.makedirs(BG_DIR, exist_ok=True)

IMG_CALM = os.path.expanduser('~/workspace/imagine_media/media-generation-ppt-peace-light-blue-dawn-0-f7707a35-e7e6-4b17-b341-bfa0ced6a551.webp')
IMG_PATH = os.path.expanduser('~/workspace/imagine_media/media-generation-ppt-peace-light-blue-water-0-74e99405-1f3a-402e-9d38-09d34761338c.webp')

W, H = 2000, 1125
NAVY = RGBColor(0x1F, 0x2A, 0x44)
DARKBLUE = RGBColor(0x1E, 0x3A, 0x5F)
BRIGHTRED = RGBColor(0xFF, 0x00, 0x00)
DARKRED = RGBColor(0xC0, 0x00, 0x00)
GOLD = RGBColor(0xB8, 0x86, 0x0B)
SLATE = RGBColor(0x33, 0x33, 0x33)
WHITE = RGBColor(0xFF, 0xFF, 0xFF)
COVERBLUE = RGBColor(0x00, 0x20, 0x60)

FONT_YAHEI = '微软雅黑'
FONT_HEI = '黑体'
FONT_KAI = '楷体'


def crop169(path):
    im = Image.open(path).convert('RGB')
    w, h = im.size
    target = 16 / 9
    if w / h > target:
        nw = int(h * target)
        x0 = (w - nw) // 2
        im = im.crop((x0, 0, x0 + nw, h))
    else:
        nh = int(w / target)
        y0 = (h - nh) // 2
        im = im.crop((0, y0, w, y0 + nh))
    return im.resize((W, H), Image.LANCZOS)


def wash(im, alpha):
    base = Image.new('RGB', (W, H), (255, 255, 255))
    return Image.blend(im, base, alpha)


def save_bg(name, img):
    p = os.path.join(BG_DIR, name)
    img.convert('RGB').save(p, quality=90)
    return p


bg_calm_cover = save_bg('calm_cover.jpg', wash(crop169(IMG_CALM), 0.62))
bg_calm = save_bg('calm.jpg', wash(crop169(IMG_CALM), 0.70))
bg_calm_div = save_bg('calm_div.jpg', wash(crop169(IMG_CALM), 0.66))
bg_path = save_bg('path.jpg', wash(crop169(IMG_PATH), 0.70))
bg_path_div = save_bg('path_div.jpg', wash(crop169(IMG_PATH), 0.66))

prs = Presentation()
prs.slide_width = Inches(13.333)
prs.slide_height = Inches(7.5)
BLANK = prs.slide_layouts[6]
SW, SH = 13.333, 7.5


def set_run(run, text, font, size, bold=True, color=SLATE):
    run.text = text
    f = run.font
    f.name = font
    f.size = Pt(size)
    f.bold = bold
    f.color.rgb = color
    rPr = run._r.get_or_add_rPr()
    rPr.set('ea', font)
    rPr.set('cs', font)
    rPr.set('lang', 'zh-CN')


def add_text(slide, left, top, width, height, paras, align=PP_ALIGN.LEFT,
             anchor=MSO_ANCHOR.TOP, line_spacing=1.25, space_after=10):
    tb = slide.shapes.add_textbox(Inches(left), Inches(top), Inches(width), Inches(height))
    tf = tb.text_frame
    tf.word_wrap = True
    tf.vertical_anchor = anchor
    tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = 0
    for i, p in enumerate(paras):
        para = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        para.alignment = p.get('align', align)
        para.line_spacing = p.get('line_spacing', line_spacing)
        para.space_after = Pt(p.get('space_after', space_after))
        runs = [(p['runs'], p['font'], p['size'], p.get('bold', True), p.get('color', SLATE))] \
            if isinstance(p['runs'], str) else p['runs']
        for (t, fn, sz, b, c) in runs:
            set_run(para.add_run(), t, fn, sz, b, c)
    return tb


def add_bg(slide, path):
    slide.shapes.add_picture(path, 0, 0, width=Inches(SW), height=Inches(SH))


def add_accent(slide, left=0.92, top=1.55, width=1.2, height=0.09, color=GOLD):
    shp = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(left), Inches(top), Inches(width), Inches(height))
    shp.fill.solid()
    shp.fill.fore_color.rgb = color
    shp.line.fill.background()
    shp.shadow.inherit = False
    return shp


def add_page_num(slide, n, total, color=RGBColor(0x88, 0x88, 0x88)):
    add_text(slide, 12.3, 7.05, 0.7, 0.35,
             [{'runs': '%d / %d' % (n, total), 'font': FONT_YAHEI, 'size': 16, 'color': color, 'align': PP_ALIGN.RIGHT}])


def content_title(slide, title):
    add_text(slide, 0.9, 0.55, 11.5, 1.0,
             [{'runs': title, 'font': FONT_HEI, 'size': 44, 'color': DARKBLUE}])
    add_accent(slide)


def verse_block(slide, ref, text, top, size=30, ref_color=DARKRED, ref_size=26, width=11.5):
    paras = [
        {'runs': ref, 'font': FONT_HEI, 'size': ref_size, 'color': ref_color, 'space_after': 6},
        {'runs': text, 'font': FONT_YAHEI, 'size': size, 'color': NAVY, 'line_spacing': 1.4},
    ]
    return add_text(slide, 0.9, top, width, 3.4, paras)


def divider(slide, num_title, subtitle, ref, text, bg, n, total, verse_size=30):
    add_bg(slide, bg)
    add_text(slide, 0.9, 1.55, 11.5, 1.2,
             [{'runs': num_title, 'font': FONT_HEI, 'size': 56, 'color': DARKBLUE, 'align': PP_ALIGN.CENTER}])
    add_text(slide, 0.9, 2.85, 11.5, 0.7,
             [{'runs': subtitle, 'font': FONT_YAHEI, 'size': 30, 'color': DARKRED, 'align': PP_ALIGN.CENTER}])
    paras = [
        {'runs': ref, 'font': FONT_HEI, 'size': 28, 'color': DARKRED, 'align': PP_ALIGN.CENTER, 'space_after': 6},
        {'runs': text, 'font': FONT_YAHEI, 'size': verse_size, 'color': NAVY, 'align': PP_ALIGN.CENTER, 'line_spacing': 1.4},
    ]
    add_text(slide, 0.9, 3.75, 11.5, 2.6, paras)
    add_page_num(slide, n, total)


def add_card(slide, left, top, width, text, num, text_color=SLATE, fill=RGBColor(0xFF, 0xFF, 0xFF),
            line_color=RGBColor(0xC9, 0xD6, 0xE8), font_size=26):
    """要点卡片：编号徽章 + 正文，高度按行数自动计算，返回下一张卡片的 top"""
    import math
    text_w = width - 1.45
    chars_per_line = max(10, int(text_w / (font_size / 72.0)))
    lines = max(1, math.ceil(len(text) / chars_per_line))
    height = 0.62 + lines * 0.52
    shp = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(left), Inches(top), Inches(width), Inches(height))
    shp.fill.solid()
    shp.fill.fore_color.rgb = fill
    shp.line.color.rgb = line_color
    shp.line.width = Pt(1.25)
    shp.shadow.inherit = False
    badge = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(left + 0.22), Inches(top + (height - 0.6) / 2), Inches(0.6), Inches(0.6))
    badge.fill.solid()
    badge.fill.fore_color.rgb = NAVY
    badge.line.fill.background()
    badge.shadow.inherit = False
    tf = badge.text_frame
    tf.word_wrap = True
    tf.vertical_anchor = MSO_ANCHOR.MIDDLE
    tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = 0
    para = tf.paragraphs[0]
    para.alignment = PP_ALIGN.CENTER
    set_run(para.add_run(), num, FONT_YAHEI, 24, True, WHITE)
    tb = slide.shapes.add_textbox(Inches(left + 1.02), Inches(top + 0.28), Inches(text_w), Inches(height - 0.56))
    tf2 = tb.text_frame
    tf2.word_wrap = True
    tf2.margin_left = tf2.margin_right = tf2.margin_top = tf2.margin_bottom = 0
    para2 = tf2.paragraphs[0]
    para2.line_spacing = 1.25
    set_run(para2.add_run(), text, FONT_YAHEI, font_size, True, text_color)
    return top + height + 0.2


def add_card_stack(slide, cards, start_top=2.05, left=0.9, width=11.5):
    """cards: list of (num, text) 或 (num, text, text_color, fill)"""
    y = start_top
    for c in cards:
        num, text = c[0], c[1]
        tc = c[2] if len(c) > 2 else SLATE
        fl = c[3] if len(c) > 3 else RGBColor(0xFF, 0xFF, 0xFF)
        y = add_card(slide, left, y, width, text, num, text_color=tc, fill=fl)
    return y


def add_branch_box(slide, left, top, width, height, label, text):
    shp = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(left), Inches(top), Inches(width), Inches(height))
    shp.fill.solid()
    shp.fill.fore_color.rgb = WHITE
    shp.line.color.rgb = NAVY
    shp.line.width = Pt(1.5)
    shp.shadow.inherit = False
    tb = slide.shapes.add_textbox(Inches(left + 0.25), Inches(top + 0.22), Inches(width - 0.5), Inches(height - 0.44))
    tf = tb.text_frame
    tf.word_wrap = True
    tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = 0
    p1 = tf.paragraphs[0]
    p1.alignment = PP_ALIGN.CENTER
    p1.line_spacing = 1.2
    p1.space_after = Pt(4)
    set_run(p1.add_run(), label, FONT_YAHEI, 26, True, DARKRED)
    for ln in text.split('\n'):
        p2 = tf.add_paragraph()
        p2.alignment = PP_ALIGN.CENTER
        p2.line_spacing = 1.3
        set_run(p2.add_run(), ln, FONT_YAHEI, 26, True, SLATE)


def add_connector_line(slide, x1, y1, x2, y2, color=GOLD, width_pt=2.0):
    from pptx.enum.shapes import MSO_CONNECTOR
    conn = slide.shapes.add_connector(MSO_CONNECTOR.STRAIGHT, Inches(x1), Inches(y1), Inches(x2), Inches(y2))
    conn.line.color.rgb = color
    conn.line.width = Pt(width_pt)
    conn.shadow.inherit = False
    return conn


TOTAL = 22
n = 0

# ---------- 1 封面 ----------
n += 1
s = prs.slides.add_slide(BLANK)
add_bg(s, bg_calm_cover)
add_text(s, 0.9, 2.2, 11.5, 1.8,
         [{'runs': '赐平安的神，成全你', 'font': FONT_HEI, 'size': 72, 'color': BRIGHTRED, 'align': PP_ALIGN.CENTER}])
add_text(s, 0.9, 4.15, 11.5, 0.8,
         [{'runs': '经文：希伯来书 13:20-21', 'font': FONT_YAHEI, 'size': 30, 'color': COVERBLUE, 'align': PP_ALIGN.CENTER}])
add_page_num(s, n, TOTAL, RGBColor(0xDD, 0xDD, 0xDD))

# ---------- 2 主题经文 ----------
n += 1
s = prs.slides.add_slide(BLANK)
add_bg(s, bg_calm)
content_title(s, '主题经文')
verse_block(s, '《希伯来书》第13章20-21节',
            '“但愿赐平安的神，就是那凭永约之血、使群羊的大牧人我主耶稣从死里复活的神，在各样善事上成全你们，叫你们遵行他的旨意；又藉着耶稣基督在你们心里行他所喜悦的事。愿荣耀归给他，直到永永远远。阿们。”',
            2.1, size=32, ref_color=BRIGHTRED)
add_page_num(s, n, TOTAL)

# ---------- 3 主旨句（思维导图） ----------
n += 1
s = prs.slides.add_slide(BLANK)
add_bg(s, bg_calm)
content_title(s, '主旨句')
# 中心枢纽
hub = s.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(4.47), Inches(1.95), Inches(4.4), Inches(0.95))
hub.fill.solid()
hub.fill.fore_color.rgb = NAVY
hub.line.fill.background()
hub.shadow.inherit = False
htf = hub.text_frame
htf.word_wrap = True
htf.vertical_anchor = MSO_ANCHOR.MIDDLE
htf.margin_left = htf.margin_right = htf.margin_top = htf.margin_bottom = 0
hp = htf.paragraphs[0]
hp.alignment = PP_ALIGN.CENTER
set_run(hp.add_run(), '赐平安的神，成全你', FONT_YAHEI, 28, True, WHITE)
# 三个分支
add_branch_box(s, 0.9, 4.15, 3.6, 2.4, '① 已成就', '凭永约之血\n使大牧人耶稣\n从死里复活')
add_branch_box(s, 4.87, 4.15, 3.6, 2.4, '② 正运行', '藉耶稣基督\n在你心里工作\n成全你行祂旨意')
add_branch_box(s, 8.83, 4.15, 3.6, 2.4, '③ 终目的', '使荣耀归给祂')
add_connector_line(s, 6.67, 2.9, 2.7, 4.15)
add_connector_line(s, 6.67, 2.9, 6.67, 4.15)
add_connector_line(s, 6.67, 2.9, 10.63, 4.15)
add_page_num(s, n, TOTAL)

# ---------- 4 引言（要点卡片） ----------
n += 1
s = prs.slides.add_slide(BLANK)
add_bg(s, bg_path)
content_title(s, '引言')
add_card_stack(s, [
    ('①', '我们常把信仰活成压力：更努力，神才祝福我。'),
    ('②', '但这里不是命令，而是祝福祷告：不是“你们要”，而是“愿神”。'),
    ('③', '福音的次序：神先做，我们才做；神先赐平安，我们才有力行善。'),
])
add_page_num(s, n, TOTAL)

# ---------- 5 一、平安的根基 ----------
n += 1
s = prs.slides.add_slide(BLANK)
divider(s, '一、平安的根基', '——复活的牧人与永约的血（20节）',
        '《希伯来书》第13章20节',
        '“但愿赐平安的神，就是那凭永约之血、使群羊的大牧人我主耶稣从死里复活的神……”',
        bg_calm_div, n, TOTAL, verse_size=30)

# ---------- 6 一-1 赐平安的神（要点卡片） ----------
n += 1
s = prs.slides.add_slide(BLANK)
add_bg(s, bg_calm)
content_title(s, '1. “赐平安的神”不是安抚，而是和好')
add_card_stack(s, [
    ('①', '“平安”不只是内心平静，而是与神和好。'),
    ('②', '真正的平安不来自环境，而来自复活的牧人已经为你舍命。'),
])
add_page_num(s, n, TOTAL)

# ---------- 7 一-2 永约之血（要点卡片） ----------
n += 1
s = prs.slides.add_slide(BLANK)
add_bg(s, bg_calm)
content_title(s, '2. “永约之血”是平安的根基')
add_card_stack(s, [
    ('①', '牛羊的血不能永远除罪。'),
    ('②', '耶稣的血立了永约，这约不因你的软弱而失效。'),
    ('③', '神看的不是你的表现，而是祂儿子已经流出的血。'),
])
add_page_num(s, n, TOTAL)

# ---------- 8 新约的应许（一）耶31:31-32 ----------
n += 1
s = prs.slides.add_slide(BLANK)
add_bg(s, bg_calm)
content_title(s, '新约的应许（一）')
verse_block(s, '《耶利米书》第31章31-32节',
            '“耶和华说：日子将到，我要与以色列家和犹大家另立新约。不像我拉着他们祖宗的手，领他们出埃及地的时候，与他们所立的约。我虽作他们的丈夫，他们却背了我的约。这是耶和华说的。”',
            2.1, size=30)
add_page_num(s, n, TOTAL)

# ---------- 9 新约的应许（二）耶31:33-34 ----------
n += 1
s = prs.slides.add_slide(BLANK)
add_bg(s, bg_calm)
content_title(s, '新约的应许（二）')
verse_block(s, '《耶利米书》第31章33-34节',
            '“耶和华说：那些日子以后，我与以色列家所立的约乃是这样：我要将我的律法放在他们里面，写在他们心上。我要作他们的神，他们要作我的子民。他们各人不再教导自己的邻舍和自己的弟兄说：‘你该认识耶和华’，因为他们从最小的到至大的都必认识我。我要赦免他们的罪孽，不再记念他们的罪恶。这是耶和华说的。”',
            2.1, size=30)
add_page_num(s, n, TOTAL)

# ---------- 9 一-3 大牧人耶稣（要点卡片） ----------
n += 1
s = prs.slides.add_slide(BLANK)
add_bg(s, bg_calm)
content_title(s, '3. “大牧人”耶稣')
add_card_stack(s, [
    ('①', '诗篇23篇、以西结书34章、约翰福音10章都指向这位牧人。'),
    ('②', '祂为羊舍命，又复活了——死亡不能拘禁祂。'),
    ('③', '深层点：平安不是“没有难处”，而是你属于一位胜过死亡的大牧人。', DARKRED, RGBColor(0xFD, 0xF0, 0xF0)),
])
add_page_num(s, n, TOTAL)

# ---------- 10 圣经中的牧人 ----------
n += 1
s = prs.slides.add_slide(BLANK)
add_bg(s, bg_calm)
content_title(s, '圣经中的牧人')
verse_block(s, '《诗篇》第23篇1节', '“耶和华是我的牧者，我必不致缺乏。”', 2.05, size=30)
verse_block(s, '《以西结书》第34章23节', '“我必立一牧人照管他们，牧养他们，就是我的仆人大卫。他必牧养他们，作他们的牧人。”', 3.95, size=30)
verse_block(s, '《约翰福音》第10章11节', '“我是好牧人；好牧人为羊舍命。”', 5.85, size=30)
add_page_num(s, n, TOTAL)

# ---------- 11 二、平安的工作 ----------
n += 1
s = prs.slides.add_slide(BLANK)
divider(s, '二、平安的工作', '——神在你里面成全（21节上）',
        '《希伯来书》第13章21节上',
        '“在各样善事上成全你们，叫你们遵行他的旨意……”',
        bg_path_div, n, TOTAL, verse_size=30)

# ---------- 12 二-1 成全（要点卡片） ----------
n += 1
s = prs.slides.add_slide(BLANK)
add_bg(s, bg_path)
content_title(s, '1. “成全”原文是 καταρτίζω')
add_card_stack(s, [
    ('①', '“成全”用于：接骨、补网、修复、装备。'),
    ('②', '神不是等你完美才用你，而是在你破碎时修复你。'),
])
add_page_num(s, n, TOTAL)

# ---------- 13 补网与挽回 ----------
n += 1
s = prs.slides.add_slide(BLANK)
add_bg(s, bg_path)
content_title(s, '补网与挽回')
verse_block(s, '《马太福音》第4章21节',
            '“从那里往前走，又看见弟兄二人，就是西庇太的儿子雅各和他兄弟约翰，同他们的父亲西庇太在船上补网，耶稣就招呼他们。”',
            2.1, size=30)
verse_block(s, '《加拉太书》第6章1节',
            '“弟兄们，若有人偶然被过犯所胜，你们属灵的人就当用温柔的心把他挽回过来；又当自己小心，恐怕也被引诱。”',
            4.95, size=30)
add_page_num(s, n, TOTAL)

# ---------- 14 二-2 次序不能颠倒（要点卡片） ----------
n += 1
s = prs.slides.add_slide(BLANK)
add_bg(s, bg_path)
content_title(s, '2. 次序不能颠倒')
add_card_stack(s, [
    ('①', '不是你先行善，神才成全；是神先成全你，你才能遵行祂旨意。'),
    ('②', '善行是结果，不是条件。'),
])
add_page_num(s, n, TOTAL)

# ---------- 15 二-3 应用（要点卡片） ----------
n += 1
s = prs.slides.add_slide(BLANK)
add_bg(s, bg_path)
content_title(s, '3. 应用')
add_card_stack(s, [
    ('①', '你像破网、断骨、迷羊，但神是工匠、医生、牧人。'),
    ('②', '祂专做接合、修补、复位的工作。'),
    ('③', '深层点：圣洁不是靠自己硬撑，而是让神在你里面重新校准你。', DARKRED, RGBColor(0xFD, 0xF0, 0xF0)),
])
add_page_num(s, n, TOTAL)

# ---------- 16 三、平安的管道 ----------
n += 1
s = prs.slides.add_slide(BLANK)
divider(s, '三、平安的管道', '——藉耶稣基督在心里运行（21节中）',
        '《希伯来书》第13章21节中',
        '“又藉着耶稣基督在你们心里行他所喜悦的事。”',
        bg_path_div, n, TOTAL, verse_size=30)

# ---------- 17 三-1 不是外在律法（要点卡片） ----------
n += 1
s = prs.slides.add_slide(BLANK)
add_bg(s, bg_path)
content_title(s, '1. 不是外在律法，而是内在生命')
add_card_stack(s, [
    ('①', '宗教：外面规定，里面挣扎。'),
    ('②', '福音：基督在你里面，成为你的生命。'),
    ('③', '神把祂儿子启示在你心里。'),
])
add_page_num(s, n, TOTAL)

# ---------- 18 三-2 藉着耶稣基督（要点卡片） ----------
n += 1
s = prs.slides.add_slide(BLANK)
add_bg(s, bg_path)
content_title(s, '2. “藉着耶稣基督”')
add_card_stack(s, [
    ('①', '一切恩典都通过基督。'),
    ('②', '你的改变不是靠意志力，而是靠与基督联合。'),
])
add_page_num(s, n, TOTAL)

# ---------- 19 三-3 应用（要点卡片） ----------
n += 1
s = prs.slides.add_slide(BLANK)
add_bg(s, bg_path)
content_title(s, '3. 应用')
add_card_stack(s, [
    ('①', '你顺服，不是因为怕神不爱你，而是因祂已经爱你，祂的生命在你里面推动你。'),
    ('②', '深层点：你不是“模仿”基督，而是让基督在你里面活出来。', DARKRED, RGBColor(0xFD, 0xF0, 0xF0)),
])
add_page_num(s, n, TOTAL)

# ---------- 20 四、平安的目的 ----------
n += 1
s = prs.slides.add_slide(BLANK)
add_bg(s, bg_calm_div)
add_text(s, 0.9, 1.4, 11.5, 1.2,
         [{'runs': '四、平安的目的', 'font': FONT_HEI, 'size': 56, 'color': DARKBLUE, 'align': PP_ALIGN.CENTER}])
add_text(s, 0.9, 2.7, 11.5, 0.7,
         [{'runs': '——荣耀归给神（21节下）', 'font': FONT_YAHEI, 'size': 30, 'color': DARKRED, 'align': PP_ALIGN.CENTER}])
paras = [
    {'runs': '《希伯来书》第13章21节下', 'font': FONT_HEI, 'size': 28, 'color': DARKRED, 'align': PP_ALIGN.CENTER, 'space_after': 6},
    {'runs': '“愿荣耀归给他，直到永永远远。阿们。”', 'font': FONT_YAHEI, 'size': 30, 'color': NAVY, 'align': PP_ALIGN.CENTER, 'line_spacing': 1.4},
]
add_text(s, 0.9, 3.6, 11.5, 1.4, paras)
add_text(s, 0.9, 5.15, 11.5, 1.6,
         [{'runs': '最终目的不是我们被称赞，而是神得荣耀。你的改变都是祂的杰作。“阿们”就是确信：祂必做成。',
           'font': FONT_YAHEI, 'size': 30, 'line_spacing': 1.5, 'align': PP_ALIGN.CENTER}])
add_page_num(s, n, TOTAL)

# ---------- 21 呼召 ----------
n += 1
s = prs.slides.add_slide(BLANK)
add_bg(s, bg_calm_cover)
content_title(s, '呼召')
add_text(s, 0.9, 2.1, 11.5, 4.4,
         [{'runs': '无论你多破碎，复活的牧人活着。', 'font': FONT_YAHEI, 'size': 30, 'line_spacing': 1.5},
          {'runs': '祂的血立了永约，能接你的骨、补你的网、装备你行祂旨意。', 'font': FONT_YAHEI, 'size': 30, 'line_spacing': 1.5},
          {'runs': '不要靠自己，转向祂，让祂在你里面行祂喜悦的事，使荣耀归给祂。', 'font': FONT_YAHEI, 'size': 30, 'line_spacing': 1.5}])
add_page_num(s, n, TOTAL)

out = os.path.join(OUT_DIR, '赐平安的神，成全你_淡蓝晨光_要点版_经文分两页.pptx')
prs.save(out)
print('saved:', out)
print('slides:', len(prs.slides._sldIdLst))
