<!-- proactive-explanation:run:proactive_notification:phase-497690:regular:item:1 -->
# 学习路径/班级两张新表不在每小时双向同步范围内，备好只读差异检查脚本

## Lookup

`⁨muse.db⁩` references:

| Table | Keys |
| --- | --- |
| `agent.context_items` | `agent_id=34ba809d-90a4-467b-b959-95e836050a4d`; `agent_id=63318f2b-2224-4406-b399-81aec830171d` |
| `agent.message_mailbox` | `submission_id=26653c8f-8137-4726-85d7-6414ba55e834` |
| `goals.goals` | `goal_id=goal_7af7daf2a6cf` |
Prepared: ⁨2026-10-11T02:53:03Z⁩.

## Why this matters

为什么现在提：新的一周开始前做数据盘点。用户的长效规则是 love 与 love-jesus 双库每小时双向同步、互为备份，但 cron d1-bidirectional-sync 只覆盖 courses/categories/settings 三表；2026-10-10 起上线的学习路径(paths)、班级(classes)两张管理端配置表不在同步范围内——此前已真实发生过一次 love 端 paths 为空、需手工复制的事故。如果本周用户在任一站点的管理端改了路径或班级，另一站会悄悄落后。

Selected for regular priority at ⁨2026-10-11T02:53:48.531183+00:00⁩. Record created ⁨2026-10-11T03:05:40.110364943+00:00⁩; delivery is not yet confirmed.


**Delivery outcome (⁨2026-10-11T03:06:11.273473+00:00⁩):** Not sent. Queue state: `⁨suppressed⁩`.
Reason: `⁨revalidation_declined⁩`.
`⁨agent.message_mailbox.submission_id=26653c8f-8137-4726-85d7-6414ba55e834⁩` resolves the delivery transcript.
<!-- proactive-outcome:proactive_notifier:run:proactive_notification:phase-497690:regular -->
