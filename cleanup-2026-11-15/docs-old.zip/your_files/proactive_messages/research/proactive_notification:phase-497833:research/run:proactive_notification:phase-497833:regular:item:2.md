<!-- proactive-explanation:run:proactive_notification:phase-497833:regular:item:2 -->
# 本地 PPT 规则 1 仍是 10-15 版：补上 10-16 定稿的两条教训

## Lookup

`⁨muse.db⁩` references:

| Table | Keys |
| --- | --- |
| `agent.context_items` | `agent_id=27bb21f7-3e71-4875-bebe-358356a3b678`; `agent_id=28c5b29e-d7cb-49b2-94a8-42c208bdd80b` |
| `agent.message_mailbox` | `submission_id=041ab1cf-73e6-7381-f44c-accc8e370309` |
| `runtime.messages` | `message_id=22185e8e-136c-4952-bcaa-64d0d196d84e`; `message_id=48a9fe83-32f3-4acd-979a-c9038be2b798`; `message_id=assistant-msg-6f793001-def8-459c-8537-35650e298215`; `message_id=assistant-msg-805b5500-124d-42b6-9a8c-97f622bddd74`; `message_id=assistant-msg-90cc2a9d-d70e-41ee-a11f-64326613e2a0`; `message_id=assistant-msg-c5b72ce3-910f-4603-8c5d-5036a510ae2c`; `message_id=assistant-msg-edf4810d-78f2-4f6f-bc89-520b5d946e50`; `message_id=c9fc9b39-3bdc-4271-8ddf-22b005e6ad74`; `message_id=d727c5ce-b916-4508-8a3f-60081b1995d8` |
Prepared: ⁨2026-10-17T01:47:48Z⁩.

## Why this matters

为什么现在值得做：本地规范文件 ~/workspace/your_files/PPT规则1.md 最后修改是 2026-10-15 15:57 UTC（我已用 stat 核实，2652 字节），仍是《得享安息》版基线：封面 72pt、分段标题 56pt、无 WPS 兼容章节、无要点卡片/思维导图、无长经文拆页规则。而 2026-10-16《赐平安的神，成全你》25 页定稿（source:57）已把基线推高，并暴露了一个真实兼容故障（source:44–source:45：第 3 页思维导图的 cxnSp 连接器触发 WPS 手机端只读锁定）。ai-rules 里的 ppt-rules.md（2026-10-16 14:52 写）已包含这些新教训，但本地规范文件没有——两份规范不一致，下一份 PPT 若只按本地文件做会回归。待投递的 pending 项“PPT 规则 1 已落后今天的两条教训”指的就是这个缺口；ai-rules 侧已补，剩本地文件这一个缺口，不要重复推 ai-rules。

Selected for regular priority at ⁨2026-10-17T01:48:58.794196+00:00⁩. Record created ⁨2026-10-18T01:58:59.073466607+00:00⁩; delivery is not yet confirmed.


**Delivery outcome (⁨2026-10-18T01:59:33.173153+00:00⁩):** Not sent. Queue state: `⁨suppressed⁩`.
Reason: `⁨revalidation_declined⁩`.
`⁨agent.message_mailbox.submission_id=041ab1cf-73e6-7381-f44c-accc8e370309⁩` resolves the delivery transcript.
<!-- proactive-outcome:proactive_notifier:run:proactive_notification:phase-497833:regular -->
