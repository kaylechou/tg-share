<!-- proactive-explanation:run:proactive_notification:phase-497670:high:item:2 -->
# 5 张新表仍在同步/备份之外——建议只纳 3 张通用配置表，2 张学员级表保持独立

## Lookup

`⁨muse.db⁩` references:

| Table | Keys |
| --- | --- |
| `agent.context_items` | `agent_id=485f2460-c79c-42d5-8754-486c1169de5a`; `agent_id=90e0ce95-cad1-44b5-a905-851bbe849970` |
| `agent.message_mailbox` | `submission_id=645c5ade-4fbc-4727-4c9a-d7081dfa0465` |
| `runtime.messages` | `message_id=assistant-msg-598225e2-b912-4fbb-a516-f466f8fd1247` |
Prepared: ⁨2026-10-10T06:49:38Z⁩.

## Why this matters

为什么现在提：今天你已经亲手踩到这个坑——love 的 D1 里 paths 表是空的（只写了 love-jesus），手动补了 4 条路径才恢复（source:41）。根因是新功能带来的 5 张表既不在每小时双向同步里，也不在每日 GitHub 备份里。我已从源码和 cron 定义里把清单和覆盖现状核实清楚（本条是对待发送告警 2026-10-10T04:48 的具体化版本，附已核实细节；若那条已发送，以本条为准）。

Selected for high priority at ⁨2026-10-10T06:51:06.066928+00:00⁩. Record created ⁨2026-10-10T11:19:09.728881294+00:00⁩; delivery is not yet confirmed.


**Delivery outcome (⁨2026-10-10T11:19:14.210187+00:00⁩):** Not sent. Queue state: `⁨suppressed⁩`.
Reason: `⁨revalidation_declined⁩`.
`⁨agent.message_mailbox.submission_id=645c5ade-4fbc-4727-4c9a-d7081dfa0465⁩` resolves the delivery transcript.
<!-- proactive-outcome:proactive_notifier:run:proactive_notification:phase-497670:high -->
