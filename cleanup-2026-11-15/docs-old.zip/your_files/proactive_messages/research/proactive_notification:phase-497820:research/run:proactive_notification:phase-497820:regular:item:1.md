<!-- proactive-explanation:run:proactive_notification:phase-497820:regular:item:1 -->
# PPT 规则 1 已落后今天的两条教训：补 WPS 兼容与大字号基线

## Lookup

`⁨muse.db⁩` references:

| Table | Keys |
| --- | --- |
| `agent.context_items` | `agent_id=550924e4-872a-4d51-b8be-117a87d946c1`; `agent_id=d07ed026-9990-4644-b3f3-766fbb4ae1d3` |
| `agent.message_mailbox` | `submission_id=47693077-c0f9-9fcb-440f-793bc41a2066` |
| `memory.claims` | `claim_id=4ee1ff16125d6e7f1f28535b0ca5a3f5`; `claim_id=9cf8f6b55ed60af67d82c9db64d055a0`; `claim_id=b7c29ee7e70d09ae9f60993cc43842aa` |
| `runtime.messages` | `message_id=assistant-msg-6f793001-def8-459c-8537-35650e298215` |
Prepared: ⁨2026-10-16T12:47:08Z⁩.

## Why this matters

为什么现在提：今天《赐平安的神，成全你》一轮里出了两条新 standing 规则——WPS 兼容画法、逐页查挤+字体能大就大——但 `~/workspace/your_files/PPT规则1.md` 仍是 2026-10-15 15:57 的版本，我 grep 核查过，里面“连接器/cxnSp/圆角/阴影/WPS/拥挤/思维导图/卡片”一个词都没有，字号还停留在旧基线（封面 72pt、分段标题 56pt）。不补上，下次讲道 PPT 容易重犯同样的 WPS 只读 bug、又从小字号起步。

Selected for regular priority at ⁨2026-10-16T12:47:29.216627+00:00⁩. Record created ⁨2026-10-17T01:49:53.681400339+00:00⁩; delivery is not yet confirmed.


**Delivery outcome (⁨2026-10-17T01:50:21.196356+00:00⁩):** Sent. Queue state: `⁨delivered⁩`.
Reason: `⁨delivered⁩`.
`⁨agent.message_mailbox.submission_id=47693077-c0f9-9fcb-440f-793bc41a2066⁩` resolves the delivery transcript.
<!-- proactive-outcome:proactive_notifier:run:proactive_notification:phase-497820:regular -->
