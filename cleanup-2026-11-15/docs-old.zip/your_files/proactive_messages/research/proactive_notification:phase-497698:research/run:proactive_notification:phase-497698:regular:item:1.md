<!-- proactive-explanation:run:proactive_notification:phase-497698:regular:item:1 -->
# 给每小时 D1 同步加上 classes/paths 表的只读漂移检测

## Lookup

`⁨muse.db⁩` references:

| Table | Keys |
| --- | --- |
| `agent.context_items` | `agent_id=0d6014b1-7f53-4a00-a87b-1228f1cc4d86`; `agent_id=b3d0e898-fa44-43c0-ae2c-74ffaab3d100` |
| `agent.message_mailbox` | `submission_id=d355357d-0702-d92d-595d-8e82d73a3088` |
Prepared: ⁨2026-10-11T10:47:25Z⁩.

## Why this matters

为什么现在提：今天 love 站新建了「爱心青年团契」班级后，love-jesus 的 classes 表为空长达数小时，直到下午 15:21 的一次人工检查才发现并手动复制。用户当时的边界是：classes 表暂时不纳入自动同步（两站各自独立）——但明确说检测要继续（"不影响你之后自己检测就行"）。同理，paths 表上周也发生过单边为空的漂移，靠人工复制修好。这两个新表都不在每小时同步脚本覆盖范围内（cron 定义只写 courses/categories/settings 三表），以后再漂移还是只能靠人工碰巧发现。

Selected for regular priority at ⁨2026-10-11T10:48:12.002182+00:00⁩. Record created ⁨2026-10-12T11:30:00.701768942+00:00⁩; delivery is not yet confirmed.


**Delivery outcome (⁨2026-10-12T11:30:08.138505+00:00⁩):** Sent. Queue state: `⁨delivered⁩`.
Reason: `⁨delivered⁩`.
`⁨agent.message_mailbox.submission_id=d355357d-0702-d92d-595d-8e82d73a3088⁩` resolves the delivery transcript.
<!-- proactive-outcome:proactive_notifier:run:proactive_notification:phase-497698:regular -->
