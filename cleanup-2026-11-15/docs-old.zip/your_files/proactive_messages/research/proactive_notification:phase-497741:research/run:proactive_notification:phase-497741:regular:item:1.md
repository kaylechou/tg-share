<!-- proactive-explanation:run:proactive_notification:phase-497741:regular:item:1 -->
# Kasumi 自定义规则 direct 出口问题——源码核验结论（供调试参考）

## Lookup

`⁨muse.db⁩` references:

| Table | Keys |
| --- | --- |
| `agent.context_items` | `agent_id=5aa7b9e4-1145-4c61-a0df-3f81c4f74c77`; `agent_id=f390a3dc-cc4b-41c3-a987-cf3901adfdb2` |
| `agent.message_mailbox` | `submission_id=00ffa574-8397-ae0f-c47a-5013b422c56d` |
Prepared: ⁨2026-10-13T06:00:59Z⁩.

## Why this matters

为什么现在值得准备：用户正在和主 agent 实时调试 Kasumi 自定义路由——`geosite:cn → block` 能启动，`→ direct` 不能。主 agent 已凭印象说"direct 出口存在"，我用 v0.4.8（用户在用的版本）源码做了独立核验，结论一致且更完整。

Selected for regular priority at ⁨2026-10-13T06:01:29.807473+00:00⁩. Record created ⁨2026-10-15T02:25:11.027542122+00:00⁩; delivery is not yet confirmed.


**Delivery outcome (⁨2026-10-15T02:25:15.743159+00:00⁩):** Not sent. Queue state: `⁨suppressed⁩`.
Reason: `⁨revalidation_declined⁩`.
`⁨agent.message_mailbox.submission_id=00ffa574-8397-ae0f-c47a-5013b422c56d⁩` resolves the delivery transcript.
<!-- proactive-outcome:proactive_notifier:run:proactive_notification:phase-497741:regular -->
